
local robot_info = {
   ["Cayman"] = {
        key = [[Cayman]],
        icon = [[8]],
        catch_fish = 41,
    },
   ["白色喷泉蜀黍"] = {
        key = [[白色喷泉蜀黍]],
        icon = [[6]],
        catch_fish = 7,
    },
   ["神诚"] = {
        key = [[神诚]],
        icon = [[3]],
        catch_fish = 13,
    },
   ["MicroWings"] = {
        key = [[MicroWings]],
        icon = [[2]],
        catch_fish = 34,
    },
   ["传说哥"] = {
        key = [[传说哥]],
        icon = [[2]],
        catch_fish = 43,
    },
   ["HinanaiTokiko"] = {
        key = [[HinanaiTokiko]],
        icon = [[1]],
        catch_fish = 13,
    },
   ["阿菲"] = {
        key = [[阿菲]],
        icon = [[5]],
        catch_fish = 75,
    },
   ["鏡歌"] = {
        key = [[鏡歌]],
        icon = [[7]],
        catch_fish = 22,
    },
   ["李子alt"] = {
        key = [[李子alt]],
        icon = [[4]],
        catch_fish = 44,
    },
   ["深蓝的审判"] = {
        key = [[深蓝的审判]],
        icon = [[9]],
        catch_fish = 38,
    },
   ["minorin"] = {
        key = [[minorin]],
        icon = [[5]],
        catch_fish = 66,
    },
   ["鄙人很悲剧"] = {
        key = [[鄙人很悲剧]],
        icon = [[5]],
        catch_fish = 88,
    },
   ["凉宫春喵喵"] = {
        key = [[凉宫春喵喵]],
        icon = [[4]],
        catch_fish = 12,
    },
   ["东风谷の回忆"] = {
        key = [[东风谷の回忆]],
        icon = [[5]],
        catch_fish = 46,
    },
   ["落落"] = {
        key = [[落落]],
        icon = [[7]],
        catch_fish = 63,
    },
   ["noaaaaa"] = {
        key = [[noaaaaa]],
        icon = [[5]],
        catch_fish = 7,
    },
   ["candysol"] = {
        key = [[candysol]],
        icon = [[6]],
        catch_fish = 11,
    },
   ["道德弟弟"] = {
        key = [[道德弟弟]],
        icon = [[3]],
        catch_fish = 15,
    },
   ["樱道研"] = {
        key = [[樱道研]],
        icon = [[3]],
        catch_fish = 14,
    },
   ["orz之主"] = {
        key = [[orz之主]],
        icon = [[2]],
        catch_fish = 13,
    },
   ["蓝兰鹿"] = {
        key = [[蓝兰鹿]],
        icon = [[7]],
        catch_fish = 42,
    },
   ["nia"] = {
        key = [[nia]],
        icon = [[3]],
        catch_fish = 1,
    },
   ["双马尾保护协会"] = {
        key = [[双马尾保护协会]],
        icon = [[3]],
        catch_fish = 42,
    },
   ["熱血沸騰天真可愛絕對領域"] = {
        key = [[熱血沸騰天真可愛絕對領域]],
        icon = [[2]],
        catch_fish = 59,
    },
   ["Tomoyo"] = {
        key = [[Tomoyo]],
        icon = [[8]],
        catch_fish = 38,
    },
   ["Yuki希"] = {
        key = [[Yuki希]],
        icon = [[2]],
        catch_fish = 73,
    },
   ["沙耶"] = {
        key = [[沙耶]],
        icon = [[2]],
        catch_fish = 83,
    },
   ["strayer"] = {
        key = [[strayer]],
        icon = [[10]],
        catch_fish = 2,
    },
   ["Rlyeh"] = {
        key = [[Rlyeh]],
        icon = [[6]],
        catch_fish = 33,
    },
   ["摸头"] = {
        key = [[摸头]],
        icon = [[6]],
        catch_fish = 87,
    },
   ["Miku大爱"] = {
        key = [[Miku大爱]],
        icon = [[9]],
        catch_fish = 19,
    },
   ["囧郭"] = {
        key = [[囧郭]],
        icon = [[9]],
        catch_fish = 31,
    },
   ["宇宙波澜"] = {
        key = [[宇宙波澜]],
        icon = [[7]],
        catch_fish = 27,
    },
   ["BOS机械制造有限公司"] = {
        key = [[BOS机械制造有限公司]],
        icon = [[5]],
        catch_fish = 41,
    },
   ["redskylala"] = {
        key = [[redskylala]],
        icon = [[10]],
        catch_fish = 67,
    },
   ["Dalka"] = {
        key = [[Dalka]],
        icon = [[7]],
        catch_fish = 58,
    },
   ["王教练♂"] = {
        key = [[王教练♂]],
        icon = [[8]],
        catch_fish = 50,
    },
   ["秋水怪蜀黍"] = {
        key = [[秋水怪蜀黍]],
        icon = [[4]],
        catch_fish = 72,
    },
   ["oicpigsfly"] = {
        key = [[oicpigsfly]],
        icon = [[6]],
        catch_fish = 77,
    },
   ["基受"] = {
        key = [[基受]],
        icon = [[3]],
        catch_fish = 79,
    },
   ["redeva"] = {
        key = [[redeva]],
        icon = [[10]],
        catch_fish = 43,
    },
   ["爱情at上甘岭"] = {
        key = [[爱情at上甘岭]],
        icon = [[7]],
        catch_fish = 65,
    },
   ["knight35"] = {
        key = [[knight35]],
        icon = [[3]],
        catch_fish = 59,
    },
   ["久远之灯火"] = {
        key = [[久远之灯火]],
        icon = [[5]],
        catch_fish = 11,
    },
   ["rr"] = {
        key = [[rr]],
        icon = [[4]],
        catch_fish = 39,
    },
   ["八云紫17岁"] = {
        key = [[八云紫17岁]],
        icon = [[7]],
        catch_fish = 95,
    },
   ["赫罗"] = {
        key = [[赫罗]],
        icon = [[9]],
        catch_fish = 39,
    },
   ["笨蛋"] = {
        key = [[笨蛋]],
        icon = [[9]],
        catch_fish = 27,
    },
   ["不详之罩"] = {
        key = [[不详之罩]],
        icon = [[2]],
        catch_fish = 43,
    },
   ["依然Lost"] = {
        key = [[依然Lost]],
        icon = [[3]],
        catch_fish = 99,
    },
   ["堕叶"] = {
        key = [[堕叶]],
        icon = [[7]],
        catch_fish = 37,
    },
   ["雷死人了"] = {
        key = [[雷死人了]],
        icon = [[4]],
        catch_fish = 38,
    },
   ["ak1ra"] = {
        key = [[ak1ra]],
        icon = [[7]],
        catch_fish = 7,
    },
   ["吉井明久"] = {
        key = [[吉井明久]],
        icon = [[8]],
        catch_fish = 86,
    },
   ["奈野沧藤"] = {
        key = [[奈野沧藤]],
        icon = [[7]],
        catch_fish = 88,
    },
   ["非喵"] = {
        key = [[非喵]],
        icon = [[9]],
        catch_fish = 40,
    },
   ["那怒火多"] = {
        key = [[那怒火多]],
        icon = [[2]],
        catch_fish = 93,
    },
   ["多米Ka"] = {
        key = [[多米Ka]],
        icon = [[5]],
        catch_fish = 62,
    },
   ["小草"] = {
        key = [[小草]],
        icon = [[7]],
        catch_fish = 15,
    },
   ["joycn"] = {
        key = [[joycn]],
        icon = [[5]],
        catch_fish = 6,
    },
   ["秋庭夕"] = {
        key = [[秋庭夕]],
        icon = [[5]],
        catch_fish = 6,
    },
   ["夏亚阿兹纳布尔"] = {
        key = [[夏亚阿兹纳布尔]],
        icon = [[5]],
        catch_fish = 87,
    },
   ["主演"] = {
        key = [[主演]],
        icon = [[6]],
        catch_fish = 72,
    },
   ["尤里小百合"] = {
        key = [[尤里小百合]],
        icon = [[1]],
        catch_fish = 51,
    },
   ["爱德华"] = {
        key = [[爱德华]],
        icon = [[9]],
        catch_fish = 63,
    },
   ["所詮この世には弱肉強食"] = {
        key = [[所詮この世には弱肉強食]],
        icon = [[6]],
        catch_fish = 54,
    },
   ["囧橙"] = {
        key = [[囧橙]],
        icon = [[4]],
        catch_fish = 61,
    },
   ["塞巴斯疆"] = {
        key = [[塞巴斯疆]],
        icon = [[5]],
        catch_fish = 54,
    },
   ["sdvergil"] = {
        key = [[sdvergil]],
        icon = [[8]],
        catch_fish = 53,
    },
   ["果夏娜"] = {
        key = [[果夏娜]],
        icon = [[7]],
        catch_fish = 74,
    },
   ["爪执镰盾之猫"] = {
        key = [[爪执镰盾之猫]],
        icon = [[9]],
        catch_fish = 24,
    },
   ["卫龙面筋"] = {
        key = [[卫龙面筋]],
        icon = [[2]],
        catch_fish = 73,
    },
   ["Nagi"] = {
        key = [[Nagi]],
        icon = [[3]],
        catch_fish = 22,
    },
   ["abccwoos"] = {
        key = [[abccwoos]],
        icon = [[2]],
        catch_fish = 1,
    },
   ["瘋騷灬"] = {
        key = [[瘋騷灬]],
        icon = [[4]],
        catch_fish = 20,
    },
   ["zxzx461000"] = {
        key = [[zxzx461000]],
        icon = [[8]],
        catch_fish = 85,
    },
   ["falcomcn"] = {
        key = [[falcomcn]],
        icon = [[6]],
        catch_fish = 57,
    },
   ["阿拉垃圾君"] = {
        key = [[阿拉垃圾君]],
        icon = [[4]],
        catch_fish = 73,
    },
   ["睡不醒的啊皮"] = {
        key = [[睡不醒的啊皮]],
        icon = [[2]],
        catch_fish = 29,
    },
   ["雾雨油库里"] = {
        key = [[雾雨油库里]],
        icon = [[3]],
        catch_fish = 67,
    },
   ["ianak"] = {
        key = [[ianak]],
        icon = [[8]],
        catch_fish = 40,
    },
   ["Ein"] = {
        key = [[Ein]],
        icon = [[1]],
        catch_fish = 35,
    },
   ["新月冰冰"] = {
        key = [[新月冰冰]],
        icon = [[9]],
        catch_fish = 83,
    },
   ["克莱茵拉罐"] = {
        key = [[克莱茵拉罐]],
        icon = [[5]],
        catch_fish = 71,
    },
   ["still"] = {
        key = [[still]],
        icon = [[1]],
        catch_fish = 98,
    },
   ["半透明の魔法使い"] = {
        key = [[半透明の魔法使い]],
        icon = [[2]],
        catch_fish = 84,
    },
   ["把你给佐奈☆佐奈掉"] = {
        key = [[把你给佐奈☆佐奈掉]],
        icon = [[2]],
        catch_fish = 19,
    },
   ["lctimothy"] = {
        key = [[lctimothy]],
        icon = [[4]],
        catch_fish = 68,
    },
   ["dollyzero"] = {
        key = [[dollyzero]],
        icon = [[8]],
        catch_fish = 96,
    },
   ["人斬"] = {
        key = [[人斬]],
        icon = [[6]],
        catch_fish = 43,
    },
   ["Ghostsky"] = {
        key = [[Ghostsky]],
        icon = [[7]],
        catch_fish = 77,
    },
   ["撸哥"] = {
        key = [[撸哥]],
        icon = [[4]],
        catch_fish = 71,
    },
   ["艾尔就是艾尔"] = {
        key = [[艾尔就是艾尔]],
        icon = [[5]],
        catch_fish = 41,
    },
   ["比那民居天子"] = {
        key = [[比那民居天子]],
        icon = [[7]],
        catch_fish = 96,
    },
   ["爱尔克路·水水"] = {
        key = [[爱尔克路·水水]],
        icon = [[3]],
        catch_fish = 26,
    },
   ["牙念玉"] = {
        key = [[牙念玉]],
        icon = [[4]],
        catch_fish = 29,
    },
   ["overmind"] = {
        key = [[overmind]],
        icon = [[6]],
        catch_fish = 43,
    },
   ["鷲巣"] = {
        key = [[鷲巣]],
        icon = [[9]],
        catch_fish = 13,
    },
   ["hikarifocus"] = {
        key = [[hikarifocus]],
        icon = [[2]],
        catch_fish = 87,
    },
   ["火爆鹅"] = {
        key = [[火爆鹅]],
        icon = [[8]],
        catch_fish = 24,
    },

}
return robot_info
