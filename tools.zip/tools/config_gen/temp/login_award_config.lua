--[[
	ID, 天, 登录奖励名称, 登录奖励图标, 登录奖励, 需要在线时间（秒）, 充值金额, 充值奖励名称, 充值奖励图标, 充值奖励
	id, day, loginAwardName, loginAwardIcon, loginAward, , recharge, rechargeAwardName, rechargeAwardIcon, rechargeAward
]]
local login_award_config = {
 [1]={
		id = 1,
		day = [[第一天]],
		loginAwardName = [[3000金币]],
		loginAwardIcon = [[gold_1]],
		loginAward = {{goodsId=1,amount=2888}},
	},
 [2]={
		id = 2,
		day = [[第二天]],
		loginAwardName = [[体验炮台]],
		loginAwardIcon = [[gold_1]],
		loginAward = {{gunId=16,time=259200}},
	},
 [3]={
		id = 3,
		day = [[第三天]],
		loginAwardName = [[福袋X10]],
		loginAwardIcon = [[gold_1]],
		loginAward = {{goodsId=2,amount=10}},
	},
 [4]={
		id = 4,
		day = [[第四天]],
		loginAwardName = [[5000金币]],
		loginAwardIcon = [[gold_1]],
		loginAward = {{goodsId=1,amount=18888}},
	},
 [5]={
		id = 5,
		day = [[第五天]],
		loginAwardName = [[8888金币]],
		loginAwardIcon = [[gold_1]],
		loginAward = {{goodsId=2,amount=20}},
	},
 [6]={
		id = 6,
		day = [[第六天]],
		loginAwardName = [[8888金币]],
		loginAwardIcon = [[gold_1]],
		loginAward = {{goodsId=1,amount=58888}},
	},
 [7]={
		id = 7,
		day = [[第七天(登录送炮塔)]],
		loginAwardName = [[永久炮台]],
		loginAwardIcon = [[gun_05]],
		loginAward = {{gunId=16,time=0}},
	},
}
return login_award_config