local online_integral_award = {
	[1] = {
			id = 1,
			startTime = 11,
			endTime = 14,
			award = {goodsId=1,amount=2500},
		},
	[2] = {
			id = 2,
			startTime = 17,
			endTime = 23,
			award = {goodsId=5,amount=1},
		}
}
return online_integral_award