--[[
	ID, 组, 类型, 名称, 描述, 条件, 数量, 跳转, 奖励
	id, group, type, name, desc, condition, num, goto, award
]]

local guide_task = {
	[1001] = {
			id = 1001,
			name="捕鱼能手",
			desc = [[捕鱼能手]],
			infos = {
				[300] = {awards = {{goodsId=1,amount=100},{goodsId=2,amount=1,}}},
				[1000] = {awards = {{goodsId=1,amount=200},{goodsId=101,amount=2,}}},
				[2000] = {awards = {{goodsId=1,amount=500},{goodsId=100,amount=2,}}},
				[5000] = {awards = {{goodsId=1,amount=1000},{goodsId=4,amount=5,}}},
			}
		},
	[1002] = {
			id = 1002,
			name="倍率达人",
			desc = [[倍率达人]],
			infos = {
				[10] = {awards = {{goodsId=100,amount=1},{goodsId=101,amount=1}}},
				[20] = {awards = {{goodsId=102,amount=1}}},
				[50] = {awards = {{goodsId=1,amount=1000}}},
				[100] = {awards = {{gunId=11,time=86400}}},
			}
		},
	[1003] = {
			id = 1003,
			name="竞技高手",
			desc = [[竞技高手]],
			infos = {
				[1] = {awards = {{goodsId=1,amount=1000}}},
				[5] = {awards = {{goodsId=1,amount=2000}}},
				[10] = {awards = {{goodsId=1,amount=3000}}},
				[20] = {awards = {{goodsId=1,amount=5000}}},
			}
		},
	[1004] = {
			id = 1004,
			name="航海新星",
			desc = [[航海新星]],
			infos = {
				[1] = {awards = {{goodsId=1,amount=100},{goodsId=5,amount=10}}},
				[2] = {awards = {{goodsId=1,amount=200},{goodsId=5,amount=15}}},
				[3] = {awards = {{goodsId=1,amount=500},{goodsId=5,amount=20}}},
			}
		},
}
return guide_task