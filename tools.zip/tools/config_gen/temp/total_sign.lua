--[[
	累积天数, 打开箱子, 关闭箱子, 名称, 奖励图标, 奖励
	day, boxOpen, boxClose, name, awardIcon, award
]]
local total_sign = {
 {
		day = 3,
		boxOpen = [[box_0_1]],
		boxClose = [[box_0_2]],
		name = [[5000金币]],
		awardIcon = [[gold_1]],
		award = {{goodsId=1,amount=5000}}
	},
 {
		day = 6,
		boxOpen = [[box_1_1]],
		boxClose = [[box_1_2]],
		name = [[8000金币]],
		awardIcon = [[gold_2]],
		award = {{goodsId=1,amount=8000}}
	},
 {
		day = 8,
		boxOpen = [[box_2_1]],
		boxClose = [[box_2_2]],
		name = [[10000金币]],
		awardIcon = [[gold_2]],
		award = {{goodsId=5,amount=10}}
	},
 {
		day = 15,
		boxOpen = [[box_3_1]],
		boxClose = [[box_3_2]],
		name = [[30000金币]],
		awardIcon = [[gold_4]],
		award = {{goodsId=2,amount=5}}
	},
}
return total_sign