--[[
	类型, 时间, 标题, icon, 奖励
	id, time, title, icon, award
]]
local online_award = {
	[1] = {
			id = 1,
			time = 300,
			award = {goodsId=1,amount=500},
		},
	[2] = {
			id = 2,
			time = 900,
			award = {goodsId=1,amount=800},
		},
	[3] = {
			id = 3,
			time = 1800,
			award = {goodsId=5,amount=1},
		},
	[4] = {
			id = 4,
			time = 2700,
			award = {goodsId=1,amount=2000},
		},
	[5] = {
			id = 5,
			time = 3600,
			award = {goodsId=2,amount=1},
		},
}
return online_award