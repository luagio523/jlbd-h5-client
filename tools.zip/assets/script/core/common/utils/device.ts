
export default class device{

   


}